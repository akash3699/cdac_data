<!DOCTYPE html>
<html lang="en">
<head>
    <title>php test</title>
</head>
<body>
    <h1>Hello PHP</h1>

    <?php 
        $x = 100;
        $y = 200;
        $z = $x + $y;

        echo "<h1> Sum is " .  $z . "</h1>";
    ?>
    <input type="text" id="txtName" value="<?php echo "Mahesh" ?>">

</body>
</html>









