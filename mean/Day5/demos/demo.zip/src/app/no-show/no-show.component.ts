import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-no-show',
  templateUrl: './no-show.component.html',
  styleUrls: ['./no-show.component.css']
})
export class NoShowComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
